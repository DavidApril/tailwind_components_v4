# Changelog

## 2025-02-10

- Update template to Tailwind CSS v4.0.6

## 2025-01-23

- Update template to Tailwind CSS v4.0

## 2024-10-07

- Tidy tier data on pricing page

## 2024-09-23

- Fix incorrect date format on blog post page ([#1632](https://github.com/tailwindlabs/tailwindui-issues/issues/1632))
- Update all images to use absolute paths ([#1631](https://github.com/tailwindlabs/tailwindui-issues/issues/1631))

## 2024-09-13

- Update dependencies

## 2024-09-12

- Initial release
